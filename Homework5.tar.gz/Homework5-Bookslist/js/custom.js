/**
 * Custom Javascript for Booklist
 */

// Self-executing Function to run last
(function () {
    // This __SHOULD__ only run when DOM is done loading
    console.log("Hello World!")
})()
